# Reusable procedures

For each procedure record its inputs, steps, output, verification, stop conditions and observed failures. No validated procedure is supplied yet.
