# Corpas Core + GBrain starter

This is a minimal, prompt-led example, not Manuel Corpas's production configuration. Open this folder in your coding agent and follow prompts.md in order. Fill bracketed fields before use.

Requirements: coding-agent account and terminal access; internet; Git and Bun (or permission to install); GBrain from https://github.com/garrytan/gbrain; optional supported embedding key for semantic retrieval. Keyword-only is an available starting point. Check provider costs and data handling.

Keep this folder private. Only sample-notes contains fictional test data. Do not import secrets or personal records. Do not reset an existing brain. No automation or external publication is configured by this kit.

The freshness test expects Monday as the current fictional deadline, supported by the newer approved note. Installation and live retrieval must be verified on your machine. This kit has not been tested as a fresh-machine installer.
