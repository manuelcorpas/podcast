# Human objectives

Owner: [YOUR NAME]
Objective: [ONE SENTENCE]
Constraints: [TIME, DATA, APPROVAL LIMITS]

This file is human doctrine, not an agent personality.
