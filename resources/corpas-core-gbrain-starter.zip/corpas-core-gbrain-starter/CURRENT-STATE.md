# Current state

As of: [DATE]
Approved by: [OWNER]
Priorities: [UP TO THREE]
Open commitments: [ONLY VERIFIED COMMITMENTS]

Historical notes cannot silently override this approved state.
